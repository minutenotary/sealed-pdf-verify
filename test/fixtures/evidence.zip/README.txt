Evidence archive for two sealed documents (test fixture).
